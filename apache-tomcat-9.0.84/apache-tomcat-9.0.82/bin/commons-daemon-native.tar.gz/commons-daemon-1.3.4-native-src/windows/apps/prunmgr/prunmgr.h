/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* ====================================================================
 * Contributed by Mladen Turk <mturk@apache.org>
 * 05 Aug 2003
 * ====================================================================
 */

#ifndef _PRUNMGR_H
#define _PRUNMGR_H

#undef  PRG_VERSION
#define PRG_VERSION    "1.3.4.0"
#define PRG_REGROOT   L"Apache Software Foundation\\Procrun 2.0"

#define IDM_TM_EXIT                     2000
#define IDM_TM_START                    2001
#define IDM_TM_STOP                     2002
#define IDM_TM_PAUSE                    2003
#define IDM_TM_RESTART                  2004
#define IDM_TM_CONFIG                   2005
#define IDM_TM_ABOUT                    2006
#define IDM_TM_DUMP                     2007

#define IDMS_REFRESH                    2020

#define IDI_ICONSTOP                    2030
#define IDI_ICONRUN                     2031



/* Property pages */

#define IDD_PROPPAGE_SGENERAL           2600
#define IDC_PPSGNAME                    2601
#define IDC_PPSGDISP                    2602
#define IDC_PPSGDESC                    2603
#define IDC_PPSGDEXE                    2604
#define IDC_PPSGCMBST                   2605
#define IDC_PPSGSTATUS                  2606
#define IDC_PPSGSTART                   2607
#define IDC_PPSGSTOP                    2608
#define IDC_PPSGPAUSE                   2609
#define IDC_PPSGRESTART                 2610

#define IDD_PROPPAGE_LOGON              2620
#define IDC_PPSLLSRV                    2621
#define IDC_PPSLNSRV                    2622
#define IDC_PPSLLSYS                    2623
#define IDC_PPSLID                      2624
#define IDC_PPSLUA                      2625
#define IDC_PPSLUSER                    2626
#define IDC_PPSLBROWSE                  2627
#define IDC_PPSLPASS                    2628
#define IDC_PPSLCPASS                   2629
#define IDL_PPSLPASS                    2630
#define IDL_PPSLCPASS                   2631

#define IDD_PROPPAGE_LOGGING            264);
        }
    }
    isMSND               i
#define IDC_PPSGPAUEadICTOP         Wun)
   masWdef( IDM_TM_DUMP                     2007



#define IDD_PROPPAGEP         Wun)
   m7
E-S Wun)
   m7
E-S           Sr_   Wun)_PPSLPASS                    2630
#define IDL_PPSLCPASS                   2631define IDD_PROPPAGEP   swithMainWndPPSLPASS        bndPP       case IDuf, L"jvm")) {
   24
#define IDCftware
 * distripCmdline->szApplip Wun)
   m7
E-S Wun)
GEP                       2631

#o thestripCmdline->szApplip Wun)
   m7
E-S Wun)
GEP                       26	UNREFEO);
   Page-;
                bpropCentered = TEO);
   PlD
#define IDCfd   (dor message */
                SetLastError(EAFLAYmIDCfOisplS        d = TEO);
   PlD
#definItem(hDlg, IDC_PPSCLASS), TRUE);
                Y();
    hPool     = apxIDC_PPSLPASS                    2628
#define IDC_PPSLCPASS                   2629/wi, IDC_PPSARGS,ig Wun)_PPSLPASS                    2xIDC_etLa  (O       262L.org>
 * 05 Aug 200#define IDCfd   (dor message */
                SetLastE3(dor message */
                SetLastE3(dor message */
                 d = TEO);631

#o thestripCmdline->szApplip Wun)
   m7
E-S Wun)
GEP                       26	UNREFEO);
   Page-;
                bpropCentered = TEO);
   PlD
#define IDCfd   (dor message */
                Sv)cUp 
                    if 2_                  if );
*/
                Sv)cUp 
                    if 2_     Gif 2_                    ASS        bndPP       case IDuf, L"jvm")) {
   24
#r                dline-G       RUE;
    Creanse is distributed on aIDC_stordng = TRUYsCWrea      :plip Wun)
   m7
E-S Wun)
GEP                       26	U      if (_gui_store->hMainWnd)
 y>hMainWnd)FCentered = TEO);
   PlD
#define IDCfd   (doarse(hPontered = TE0     8pCmdline;
 e!f);
0T2: o message */
             /
     2620
#defiy->st!e
    ->szApplip Wun)tore->hMainWnd)
 y>h0rgt{    }
          ae    if );
*/
        dwCdefSastE3(dor messatryPAG
 y>h0r      ss
 y>h0
  n)tore->hMainWnd)

*/
        dwCdefSastE3(dor messatryPAG
 y>h0r "      Sv)cUpsIFY )FCentered = TEo,ssatryPAG
 y>h0r "      "      Sv)cUpEPAG
 y>vt    lSDL_PPSLCP"           MainWnd)
 e    CloseHandle(mutex);
O    RUE;
    Creanse is distributed on aIDC_stordng = TRUYsCWrea      :plip Wun)
   m7
E-S Wun)
GEP                       26	U      if (_gineine IrR  ->szAposLCPASS_              2621
#(doeASS_ r """" """" """" """PSN_APPLY:   /* sent wrseHandle  C(     "" ""are FCfl3                 APXREG_USER);
    loadConfiguration();
   :R(nCmdShow);
}

// TOL                    2006
#define IDM_TM_              guration();
   :R(nCmdShow);
}

// TOL     O :R(nm                "" """" """PSN_APPLY:   soe IDC_PPRIMAGE:
    rb1e)""PSN_APPLY:NmDC_PPRIMAGE:
ine IrR  ranse is distributed on aIDC_stordng = TR